package com.apd.tema2.entities;

/**
 * Utilizata pentru uniformizarea implementarii task-urilor.
 */
public interface IntersectionHandler {
    public void handle(Car car);
}
